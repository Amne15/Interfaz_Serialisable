/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaz_ser;

import java.io.Serializable;

/**
 *
 * @author usuario
 */
public class Paciente implements Serializable{
    private int idPaciente;
    private String DNIPaciente;
    private String nombrePaciente;    
    private String apellidoPaciente;    
    private String emailPaciente;    
    private String telefonoPaciente;
    private String nombreDoctor;

    public Paciente() {
    }
    

    public Paciente(int idPaciente, String DNIPaciente, String nombrePaciente, String apellidoPaciente, 
            String emailPaciente, String telefonoPaciente, String nombreDoctor) {
       this.idPaciente = idPaciente;
       this.DNIPaciente = DNIPaciente;
       this.nombrePaciente = nombrePaciente;
       this.apellidoPaciente = apellidoPaciente;
       this.emailPaciente = emailPaciente;
       this.telefonoPaciente = telefonoPaciente;
       this.nombreDoctor = nombreDoctor;
    }  

    public Paciente(String DNIPaciente, String nombrePaciente, String apellidoPaciente, String emailPaciente, String telefonoPaciente, String nombreDoctor) {
        this.DNIPaciente = DNIPaciente;
        this.nombrePaciente = nombrePaciente;
        this.apellidoPaciente = apellidoPaciente;
        this.emailPaciente = emailPaciente;
        this.telefonoPaciente = telefonoPaciente;
        this.nombreDoctor = nombreDoctor;
    }
    
    public int getIdPaciente() {
        return idPaciente;
    }
    
    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }
    public String getDNIPaciente() {
        return DNIPaciente;
    }

    public void setDNIPaciente(String DNIPaciente) {
        this.DNIPaciente = DNIPaciente;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) {
        this.nombrePaciente = nombrePaciente;
    }

    public String getApellidoPaciente() {
        return apellidoPaciente;
    }

    public void setApellidoPaciente(String apellidoPaciente) {
        this.apellidoPaciente = apellidoPaciente;
    }

    public String getEmailPaciente() {
        return emailPaciente;
    }

    public void setEmailPaciente(String emailPaciente) {
        this.emailPaciente = emailPaciente;
    }

    public String getTelefonoPaciente() {
        return telefonoPaciente;
    }

    public void setTelefonoPaciente(String telefonoPaciente) {
        this.telefonoPaciente = telefonoPaciente;
    }
    
    
    public String getNombreDoctor() {
        return nombreDoctor;
    }

    public void setNombreDoctor(String doctor) {
        this.nombreDoctor = doctor;
    }    

    @Override
    public String toString() {
        return "Paciente{" + "idPaciente=" + idPaciente + ", DNIPaciente=" + DNIPaciente + ", nombrePaciente=" + nombrePaciente + ", apellidoPaciente=" + apellidoPaciente + ", emailPaciente=" + emailPaciente + ", telefonoPaciente=" + telefonoPaciente + ", nombreDoctor=" + nombreDoctor + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + this.idPaciente;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Paciente other = (Paciente) obj;
        return this.idPaciente == other.idPaciente;
    }
    
    
    
   
    
    
}
