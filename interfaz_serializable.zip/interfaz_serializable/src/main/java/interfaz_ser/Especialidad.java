/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaz_ser;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author usuario
 */
public class Especialidad implements Serializable{
    
    int idEspecialidad;
    String nombre;
    String importancia;
    int anosEstudio ;
    String categoria;
    String codigoEspecialidad;
  

    public Especialidad() {
    }
    

    public Especialidad(int idEspecialidad, String nombre, String importancia, int anosEstudio, String categoria, String codigoEspecialidad) {
        
        this.idEspecialidad=idEspecialidad;
        this.nombre = nombre;
        this.importancia = importancia;
        this.anosEstudio = anosEstudio;
        this.categoria = categoria;
        this.codigoEspecialidad = codigoEspecialidad;
        
    }

    public Especialidad(String nombre, String importancia, int anosEstudio, String categoria, String codigoEspecialidad) {

        this.nombre = nombre;
        this.importancia = importancia;
        this.anosEstudio = anosEstudio;
        this.categoria = categoria;
        this.codigoEspecialidad = codigoEspecialidad;
    }

    public int getIdEspecialidad() {
        return idEspecialidad;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getImportancia() {
        return importancia;
    }

    public void setImportancia(String importancia) {
        this.importancia = importancia;
    }

    public int getAnosEstudio() {
        return anosEstudio;
    }

    public void setAnosEstudio(int anosEstudio) {
        this.anosEstudio = anosEstudio;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCodigoEspecialidad() {
        return codigoEspecialidad;
    }

    public void setCodigoEspecialidad(String codigoEspecialidad) {
        this.codigoEspecialidad = codigoEspecialidad;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.idEspecialidad;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Especialidad other = (Especialidad) obj;
        return this.idEspecialidad == other.idEspecialidad;
    }
    

    @Override
    public String toString() {
        return "Especialidad{" + "idEspecialidad=" + idEspecialidad + ", nombre=" + nombre + ", importancia=" + importancia + ", anosEstudio=" + anosEstudio + ", categoria=" + categoria + ", codigoEspecialidad=" + codigoEspecialidad + '}';
    }
    
    
    
}
