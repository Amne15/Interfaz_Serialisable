package interfaz_ser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class Ventana1 extends javax.swing.JFrame {

    //guardarNuevo: Save new Paciente is true, if edit Paciente is false
    public boolean guardarNuevoPac = true;
    public boolean guardarNuevoDoc = true;
    public boolean guardarNuevoEsp = true;
    
    //Position of selected ligne in Table liste
    public static int positionPac = 0;
    public static int positionDoc = 0;
    public static int positionEsp = 0;
    
    //Listas de Objetos
    public ArrayList<Paciente> lista_pacientes = new ArrayList<>();
    public ArrayList<Doctor> lista_doctors = new ArrayList<>();
    public ArrayList<Especialidad> lista_especialidad = new ArrayList<>();

    //Modelo de tablas por defecto
    public DefaultTableModel model_tabla_paciente;
    public DefaultTableModel model_tabla_doctor;
    public DefaultTableModel model_tabla_especialidad;
    
    //URL de Ficheros DAT para leer y escribir datos
    public static final String URL_OBJECT_FILE_PACIENTE = "FileSerialisable\\myFilePaciente.dat";
    public static final String URL_OBJECT_FILE_DOCTOR = "FileSerialisable\\myFileDoctor.dat";
    public static final String URL_OBJECT_FILE_ESPECIALIDAD = "FileSerialisable\\myFileEspecialidad.dat";
    //Ficheros Serialisable
    public static final File FILE_PACIENTE = new File(URL_OBJECT_FILE_PACIENTE);
    public static final File FILE_DOCTOR = new File(URL_OBJECT_FILE_DOCTOR);    
    public static final File FILE_ESPECIALIDAD = new File(URL_OBJECT_FILE_ESPECIALIDAD);
    
    
    FileOutputStream fileout_pac, fileout_doc, fileout_esp = null;
    ObjectOutputStream dataOS_pac, dataOS_doc, dataOS_esp = null;
    
    /**
     * Creates new form Ventana1
     * Constructor de Ventana1
     */
    public Ventana1(){
        initComponents();
        model_tabla_paciente = (DefaultTableModel) jTable_paciente.getModel();
        model_tabla_doctor = (DefaultTableModel) jTable_doctor.getModel();
        model_tabla_especialidad = (DefaultTableModel) jTable_especialidad.getModel();        
        
        try{
            //
            if(!FILE_PACIENTE.exists()){
                fileout_pac = new FileOutputStream(FILE_PACIENTE);  
                dataOS_pac = new ObjectOutputStream(fileout_pac);            
            }
            //
            if(!FILE_DOCTOR.exists()){
                fileout_doc = new FileOutputStream(FILE_DOCTOR);  
                dataOS_doc = new ObjectOutputStream(fileout_doc);            
            }
            //
            if(!FILE_ESPECIALIDAD.exists()){
                fileout_esp = new FileOutputStream(FILE_ESPECIALIDAD);  
                dataOS_esp = new ObjectOutputStream(fileout_esp);            
            }            
        }catch(IOException e){
            
        }        
      
        //Leer datos de la lista Paciente
        lista_pacientes = LeerFichObjectPaciente(FILE_PACIENTE);
        //Leer datos de la lista Doctors
        lista_doctors = LeerFichObjectDoctor(FILE_DOCTOR);
        //Leer datos de la lista Especialidad
        lista_especialidad = LeerFichObjectEspecialidad(FILE_ESPECIALIDAD);   
        
        //Bucle que recorra todos los doctores y los inserte en el combobox de Paciente
        for (int i = 0; i < lista_doctors.size(); i++) {
            this.jComboBox_especialidad_doctor.addItem(this.lista_doctors.get(i).getNombre());
        }
        //Bucle que recorra todos los especialidad y los inserte en el combobox de Doctor
        for (int i = 0; i < lista_especialidad.size(); i++) {
            this.jComboBox_especialidad_especialidad.addItem(this.lista_especialidad.get(i).getNombre());            
        }
        
        
        //Asigna ficheros serialisable para escribir datos de las listas de Pacientes, Doctors y specialidades
        try {            
            //conecta el flujo de bytes al flujo de datos
            fileout_pac = new FileOutputStream(FILE_PACIENTE);
            dataOS_pac = new ObjectOutputStream(fileout_pac);
            
            //conecta el flujo de bytes al flujo de datos
            fileout_doc = new FileOutputStream(FILE_DOCTOR);
            dataOS_doc = new ObjectOutputStream(fileout_doc);
            
            //conecta el flujo de bytes al flujo de datos
            fileout_esp = new FileOutputStream(FILE_ESPECIALIDAD);
            dataOS_esp = new ObjectOutputStream(fileout_esp);
            
        } catch (IOException ex) {
            Logger.getLogger(Ventana1.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
       
        //Mostrar datos
        mostrarTodosLosPacientes();
        mostrarTodosLosDoctores();
        mostrarTodosLosEspecialidades();
    }

    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane = new javax.swing.JTabbedPane();
        jPanel_Especialidad = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable_especialidad = new javax.swing.JTable();
        jLabel_nombre_especialidad = new javax.swing.JLabel();
        jLabel_importancia_especialidad = new javax.swing.JLabel();
        jLabel_yearestudio_especialidad = new javax.swing.JLabel();
        jTextField_nombre_especialidad = new javax.swing.JTextField();
        jTextField_importancia_especialidad = new javax.swing.JTextField();
        jButton_guardar_especialidad = new javax.swing.JButton();
        jButton_cancelar_especialidad = new javax.swing.JButton();
        jButton_borrar_especialidad = new javax.swing.JButton();
        jButton_modificar_especialidad = new javax.swing.JButton();
        jButton_aniadir_especialidad = new javax.swing.JButton();
        jLabel_categoria_especialidad = new javax.swing.JLabel();
        jTextField_categoria_especialidad = new javax.swing.JTextField();
        jTextField_anosestudio_especialidad = new javax.swing.JFormattedTextField();
        jLabel_codespecialidad_especialidad = new javax.swing.JLabel();
        jTextField_codigo_especialidad = new javax.swing.JTextField();
        jPanel_doctor = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_doctor = new javax.swing.JTable();
        jLabel_nombre_doctor = new javax.swing.JLabel();
        jLabel_email_doctor = new javax.swing.JLabel();
        jLabel_telefono_doctor = new javax.swing.JLabel();
        jTextField_nombre_doctor = new javax.swing.JTextField();
        jTextField_email_doctor = new javax.swing.JTextField();
        jButton_guardar_doctor = new javax.swing.JButton();
        jButton_cancelar_doctor = new javax.swing.JButton();
        jButton_aniadir_doctor = new javax.swing.JButton();
        jButton_modificar_doctor = new javax.swing.JButton();
        jButton_borrar_doctor = new javax.swing.JButton();
        jLabel_especialidad_doctor = new javax.swing.JLabel();
        jTextField_direccion_doctor = new javax.swing.JTextField();
        jLabel_direccion_doctor = new javax.swing.JLabel();
        jTextField_telefono_doctor = new javax.swing.JFormattedTextField();
        jTextField_apellido_doctor = new javax.swing.JTextField();
        jLabel_apellido_doctor = new javax.swing.JLabel();
        jComboBox_especialidad_especialidad = new javax.swing.JComboBox<>();
        jPanel_paciente = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_paciente = new javax.swing.JTable();
        jButton_aniadir_paciente = new javax.swing.JButton();
        jButton_modificar_paciente = new javax.swing.JButton();
        jButton_borrar_paciente = new javax.swing.JButton();
        jLabel_dni_paciente = new javax.swing.JLabel();
        jLabel_apellido_paciente = new javax.swing.JLabel();
        jLabel_email_paciente = new javax.swing.JLabel();
        jTextField_apellidos_paciente = new javax.swing.JTextField();
        jButton_guardar_paciente = new javax.swing.JButton();
        jButton_cancelar_paciente = new javax.swing.JButton();
        jTextField_telefono_paciente = new javax.swing.JTextField();
        jLabel_telefono_paciente = new javax.swing.JLabel();
        jTextField_email_paciente = new javax.swing.JFormattedTextField();
        jLabel_nombre_paciente1 = new javax.swing.JLabel();
        jTextField_nombre_paciente = new javax.swing.JTextField();
        jTextField_dni_paciente = new javax.swing.JTextField();
        jLabel_telefono_paciente1 = new javax.swing.JLabel();
        jComboBox_especialidad_doctor = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jTable_especialidad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Importancia", "AnosEstudio", "Categoria", "CodigoEspecialidad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_especialidad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_especialidadMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable_especialidad);
        if (jTable_especialidad.getColumnModel().getColumnCount() > 0) {
            jTable_especialidad.getColumnModel().getColumn(0).setResizable(false);
            jTable_especialidad.getColumnModel().getColumn(1).setResizable(false);
        }

        jLabel_nombre_especialidad.setText("Nombre:");

        jLabel_importancia_especialidad.setText("Importancia:");

        jLabel_yearestudio_especialidad.setText("AnosEstudio");

        jTextField_nombre_especialidad.setEditable(false);
        jTextField_nombre_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_nombre_especialidadActionPerformed(evt);
            }
        });

        jTextField_importancia_especialidad.setEditable(false);

        jButton_guardar_especialidad.setText("Guardar");
        jButton_guardar_especialidad.setEnabled(false);
        jButton_guardar_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_guardar_especialidadActionPerformed(evt);
            }
        });

        jButton_cancelar_especialidad.setText("Cancelar");
        jButton_cancelar_especialidad.setEnabled(false);
        jButton_cancelar_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_cancelar_especialidadActionPerformed(evt);
            }
        });

        jButton_borrar_especialidad.setText("Borrar");
        jButton_borrar_especialidad.setEnabled(false);
        jButton_borrar_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_borrar_especialidadActionPerformed(evt);
            }
        });

        jButton_modificar_especialidad.setText("Modificar");
        jButton_modificar_especialidad.setEnabled(false);
        jButton_modificar_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_modificar_especialidadActionPerformed(evt);
            }
        });

        jButton_aniadir_especialidad.setText("Añadir");
        jButton_aniadir_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_aniadir_especialidadActionPerformed(evt);
            }
        });

        jLabel_categoria_especialidad.setText("Categoria");

        jTextField_categoria_especialidad.setEditable(false);

        jTextField_anosestudio_especialidad.setEditable(false);
        jTextField_anosestudio_especialidad.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        jTextField_anosestudio_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_anosestudio_especialidadActionPerformed(evt);
            }
        });

        jLabel_codespecialidad_especialidad.setText("CodigoEspecialidad");

        jTextField_codigo_especialidad.setEditable(false);

        javax.swing.GroupLayout jPanel_EspecialidadLayout = new javax.swing.GroupLayout(jPanel_Especialidad);
        jPanel_Especialidad.setLayout(jPanel_EspecialidadLayout);
        jPanel_EspecialidadLayout.setHorizontalGroup(
            jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_EspecialidadLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel_EspecialidadLayout.createSequentialGroup()
                        .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel_importancia_especialidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel_nombre_especialidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel_yearestudio_especialidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel_categoria_especialidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel_codespecialidad_especialidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField_nombre_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_importancia_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_anosestudio_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_categoria_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel_EspecialidadLayout.createSequentialGroup()
                                    .addComponent(jButton_guardar_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton_cancelar_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jTextField_codigo_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton_aniadir_especialidad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_modificar_especialidad, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton_borrar_especialidad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(100, Short.MAX_VALUE))
        );
        jPanel_EspecialidadLayout.setVerticalGroup(
            jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_EspecialidadLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_nombre_especialidad)
                    .addComponent(jTextField_nombre_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_aniadir_especialidad))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_importancia_especialidad)
                    .addComponent(jTextField_importancia_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_modificar_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_yearestudio_especialidad)
                    .addComponent(jTextField_anosestudio_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_borrar_especialidad))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_categoria_especialidad)
                    .addComponent(jTextField_categoria_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_codespecialidad_especialidad)
                    .addComponent(jTextField_codigo_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_EspecialidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_guardar_especialidad)
                    .addComponent(jButton_cancelar_especialidad))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jTabbedPane.addTab("Especialidad", jPanel_Especialidad);

        jTable_doctor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Apellido", "Email", "Telefono", "Direccion", "Especialidad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_doctor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_doctorMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_doctor);
        if (jTable_doctor.getColumnModel().getColumnCount() > 0) {
            jTable_doctor.getColumnModel().getColumn(0).setResizable(false);
            jTable_doctor.getColumnModel().getColumn(1).setResizable(false);
            jTable_doctor.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel_nombre_doctor.setText("Nombre:");

        jLabel_email_doctor.setText("Email");

        jLabel_telefono_doctor.setText("Telefono");

        jTextField_nombre_doctor.setEditable(false);
        jTextField_nombre_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_nombre_doctorActionPerformed(evt);
            }
        });

        jTextField_email_doctor.setEditable(false);
        jTextField_email_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_email_doctorActionPerformed(evt);
            }
        });

        jButton_guardar_doctor.setText("Guardar");
        jButton_guardar_doctor.setEnabled(false);
        jButton_guardar_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_guardar_doctorActionPerformed(evt);
            }
        });

        jButton_cancelar_doctor.setText("Cancelar");
        jButton_cancelar_doctor.setEnabled(false);
        jButton_cancelar_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_cancelar_doctorActionPerformed(evt);
            }
        });

        jButton_aniadir_doctor.setText("Añadir");
        jButton_aniadir_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_aniadir_doctorActionPerformed(evt);
            }
        });

        jButton_modificar_doctor.setText("Modificar");
        jButton_modificar_doctor.setEnabled(false);
        jButton_modificar_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_modificar_doctorActionPerformed(evt);
            }
        });

        jButton_borrar_doctor.setText("Borrar");
        jButton_borrar_doctor.setEnabled(false);
        jButton_borrar_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_borrar_doctorActionPerformed(evt);
            }
        });

        jLabel_especialidad_doctor.setText("Especialidad");

        jTextField_direccion_doctor.setEditable(false);

        jLabel_direccion_doctor.setText("Direccion");

        jTextField_telefono_doctor.setEditable(false);
        jTextField_telefono_doctor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        jTextField_apellido_doctor.setEditable(false);
        jTextField_apellido_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_apellido_doctorActionPerformed(evt);
            }
        });

        jLabel_apellido_doctor.setText("Apellido");

        jComboBox_especialidad_especialidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccion" }));
        jComboBox_especialidad_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_especialidad_especialidadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_doctorLayout = new javax.swing.GroupLayout(jPanel_doctor);
        jPanel_doctor.setLayout(jPanel_doctorLayout);
        jPanel_doctorLayout.setHorizontalGroup(
            jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_doctorLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                    .addGroup(jPanel_doctorLayout.createSequentialGroup()
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel_especialidad_doctor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel_direccion_doctor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_doctorLayout.createSequentialGroup()
                                .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel_email_doctor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel_telefono_doctor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel_apellido_doctor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel_nombre_doctor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)))
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel_doctorLayout.createSequentialGroup()
                                .addComponent(jButton_guardar_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(jButton_cancelar_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextField_apellido_doctor)
                                .addComponent(jTextField_email_doctor)
                                .addComponent(jTextField_telefono_doctor)
                                .addComponent(jTextField_direccion_doctor)
                                .addComponent(jComboBox_especialidad_especialidad, 0, 210, Short.MAX_VALUE)
                                .addComponent(jTextField_nombre_doctor)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_doctorLayout.createSequentialGroup()
                                .addComponent(jButton_aniadir_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(9, 9, 9))
                            .addComponent(jButton_modificar_doctor)
                            .addComponent(jButton_borrar_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(93, 93, 93))
        );
        jPanel_doctorLayout.setVerticalGroup(
            jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_doctorLayout.createSequentialGroup()
                .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_doctorLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_nombre_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_nombre_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 20, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_apellido_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_apellido_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_email_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_email_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_telefono_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_telefono_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_direccion_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_direccion_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel_especialidad_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox_especialidad_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel_doctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton_guardar_doctor)
                            .addComponent(jButton_cancelar_doctor)))
                    .addGroup(jPanel_doctorLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jButton_aniadir_doctor)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton_modificar_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton_borrar_doctor)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77))
        );

        jTabbedPane.addTab("Doctor", jPanel_doctor);

        jTable_paciente.setAutoCreateRowSorter(true);
        jTable_paciente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "DNI", "Nombre", "Apellido", "Email", "Telefono", "Doctor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable_paciente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_pacienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_paciente);
        if (jTable_paciente.getColumnModel().getColumnCount() > 0) {
            jTable_paciente.getColumnModel().getColumn(0).setHeaderValue("DNI");
            jTable_paciente.getColumnModel().getColumn(1).setHeaderValue("Nombre");
            jTable_paciente.getColumnModel().getColumn(2).setHeaderValue("Apellido");
            jTable_paciente.getColumnModel().getColumn(3).setHeaderValue("Email");
            jTable_paciente.getColumnModel().getColumn(4).setHeaderValue("Telefono");
            jTable_paciente.getColumnModel().getColumn(5).setHeaderValue("Doctor");
        }

        jButton_aniadir_paciente.setText("Añadir");
        jButton_aniadir_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_aniadir_pacienteActionPerformed(evt);
            }
        });

        jButton_modificar_paciente.setText("Modificar");
        jButton_modificar_paciente.setEnabled(false);
        jButton_modificar_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_modificar_pacienteActionPerformed(evt);
            }
        });

        jButton_borrar_paciente.setText("Borrar");
        jButton_borrar_paciente.setEnabled(false);
        jButton_borrar_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_borrar_pacienteActionPerformed(evt);
            }
        });

        jLabel_dni_paciente.setText("DNI");

        jLabel_apellido_paciente.setText("Apellidos:");

        jLabel_email_paciente.setText("Email");

        jTextField_apellidos_paciente.setEditable(false);
        jTextField_apellidos_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_apellidos_pacienteActionPerformed(evt);
            }
        });

        jButton_guardar_paciente.setText("Guardar");
        jButton_guardar_paciente.setEnabled(false);
        jButton_guardar_paciente.setRequestFocusEnabled(false);
        jButton_guardar_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_guardar_pacienteActionPerformed(evt);
            }
        });

        jButton_cancelar_paciente.setText("Cancelar");
        jButton_cancelar_paciente.setEnabled(false);
        jButton_cancelar_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_cancelar_pacienteActionPerformed(evt);
            }
        });

        jTextField_telefono_paciente.setEditable(false);
        jTextField_telefono_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_telefono_pacienteActionPerformed(evt);
            }
        });

        jLabel_telefono_paciente.setText("Telefono:");

        jTextField_email_paciente.setEditable(false);
        jTextField_email_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_email_pacienteActionPerformed(evt);
            }
        });

        jLabel_nombre_paciente1.setText("Nombre:");

        jTextField_nombre_paciente.setEditable(false);
        jTextField_nombre_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_nombre_pacienteActionPerformed(evt);
            }
        });

        jTextField_dni_paciente.setEditable(false);
        jTextField_dni_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_dni_pacienteActionPerformed(evt);
            }
        });

        jLabel_telefono_paciente1.setText("Doctor");

        jComboBox_especialidad_doctor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccion" }));
        jComboBox_especialidad_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_especialidad_doctorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_pacienteLayout = new javax.swing.GroupLayout(jPanel_paciente);
        jPanel_paciente.setLayout(jPanel_pacienteLayout);
        jPanel_pacienteLayout.setHorizontalGroup(
            jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_pacienteLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 542, Short.MAX_VALUE)
                    .addGroup(jPanel_pacienteLayout.createSequentialGroup()
                        .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel_nombre_paciente1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel_dni_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel_apellido_paciente)
                            .addComponent(jLabel_email_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel_telefono_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel_telefono_paciente1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(71, 71, 71)
                        .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel_pacienteLayout.createSequentialGroup()
                                .addComponent(jButton_guardar_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                                .addComponent(jButton_cancelar_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jComboBox_especialidad_doctor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField_nombre_paciente)
                            .addComponent(jTextField_dni_paciente)
                            .addComponent(jTextField_apellidos_paciente)
                            .addComponent(jTextField_email_paciente)
                            .addComponent(jTextField_telefono_paciente))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton_modificar_paciente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton_aniadir_paciente, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_borrar_paciente, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(99, 99, 99))
        );
        jPanel_pacienteLayout.setVerticalGroup(
            jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_pacienteLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_dni_paciente)
                    .addComponent(jTextField_dni_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_aniadir_paciente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_nombre_paciente1)
                    .addComponent(jTextField_nombre_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_modificar_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField_apellidos_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_apellido_paciente)
                    .addComponent(jButton_borrar_paciente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField_email_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_email_paciente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField_telefono_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_telefono_paciente))
                .addGap(6, 6, 6)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox_especialidad_doctor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_telefono_paciente1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel_pacienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_guardar_paciente)
                    .addComponent(jButton_cancelar_paciente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane.addTab("Paciente", jPanel_paciente);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 668, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane.getAccessibleContext().setAccessibleName("Ciudad");

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jButton_aniadir_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_aniadir_especialidadActionPerformed
        // TODO add your handling code here:
        
        positionEsp = model_tabla_especialidad.getRowCount();
        
        jTextField_nombre_especialidad.setEditable(true);
        jTextField_importancia_especialidad.setEditable(true);
        jTextField_anosestudio_especialidad.setEditable(true);
        jTextField_categoria_especialidad.setEditable(true);
        jTextField_codigo_especialidad.setEditable(true);
        jComboBox_especialidad_especialidad.setEditable(true);
        //jComboBox_especialidad_especialidad.removeAllItems();

        jButton_aniadir_especialidad.setEnabled(false);
        jButton_guardar_especialidad.setEnabled(true);
        jButton_cancelar_especialidad.setEnabled(true);

    }//GEN-LAST:event_jButton_aniadir_especialidadActionPerformed

    private void jButton_modificar_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_modificar_especialidadActionPerformed
        // TODO add your handling code here:
        
        guardarNuevoEsp = false;

        jTextField_nombre_especialidad.setEditable(true);
        jTextField_importancia_especialidad.setEditable(true);
        jTextField_anosestudio_especialidad.setEditable(true);
        jTextField_categoria_especialidad.setEditable(true);
        jTextField_codigo_especialidad.setEditable(true);

        jButton_guardar_especialidad.setEnabled(true);
        jButton_cancelar_especialidad.setEnabled(true);
        jButton_aniadir_especialidad.setEnabled(false);
        
    }//GEN-LAST:event_jButton_modificar_especialidadActionPerformed

    private void jButton_borrar_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_borrar_especialidadActionPerformed
        // TODO add your handling code here:
        
        lista_especialidad.remove(positionEsp);
        jComboBox_especialidad_especialidad.removeAllItems();
        
        //Bucle que recorra todos los especialidad y los inserte en el combobox de Doctor
        for (int i = 0; i < lista_especialidad.size(); i++) {
            jComboBox_especialidad_especialidad.addItem(lista_especialidad.get(i).getNombre());            
        }        
        
        model_tabla_especialidad.removeRow(positionEsp);
        
        jTextField_nombre_especialidad.setText("");
        jTextField_importancia_especialidad.setText("");
        jTextField_anosestudio_especialidad.setText("");
        jTextField_categoria_especialidad.setText("");
        jTextField_codigo_especialidad.setText("");

        jButton_aniadir_especialidad.setEnabled(true);
        jButton_modificar_especialidad.setEnabled(false);
        jButton_borrar_especialidad.setEnabled(false);
        jButton_guardar_especialidad.setEnabled(false);
        jButton_cancelar_especialidad.setEnabled(false);
    }//GEN-LAST:event_jButton_borrar_especialidadActionPerformed

    private void jButton_cancelar_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_cancelar_especialidadActionPerformed
        // TODO add your handling code here:

        jTextField_nombre_especialidad.setEditable(false);
        jTextField_importancia_especialidad.setEditable(false);
        jTextField_anosestudio_especialidad.setEditable(false);
        jTextField_categoria_especialidad.setEditable(false);
        jTextField_codigo_especialidad.setEditable(false);
        jComboBox_especialidad_especialidad.setEditable(false);

        jButton_aniadir_especialidad.setEnabled(true);
        jButton_guardar_especialidad.setEnabled(false);
        jButton_cancelar_especialidad.setEnabled(false);

        jTextField_nombre_especialidad.setText("");
        jTextField_importancia_especialidad.setText("");
        jTextField_anosestudio_especialidad.setText("");
        jTextField_categoria_especialidad.setText("");
        jTextField_codigo_especialidad.setText("");
        //jComboBox_especialidad_especialidad.setEditable(false);
    }//GEN-LAST:event_jButton_cancelar_especialidadActionPerformed

   
    private void jButton_guardar_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_guardar_especialidadActionPerformed
        // TODO add your handling code here:
        
        int id_Especialidad = lista_especialidad.size();
        String nombre = jTextField_nombre_especialidad.getText();
        String importancia = jTextField_importancia_especialidad.getText();
        int anosEstudio = Integer.parseInt(jTextField_anosestudio_especialidad.getText());
        String categoria = jTextField_categoria_especialidad.getText();
        String codigoEspecialidad = jTextField_codigo_especialidad.getText();
        
        if (guardarNuevoEsp == true) {
            Especialidad newEsp = new Especialidad(++id_Especialidad, nombre, importancia, anosEstudio, categoria, codigoEspecialidad);
            positionEsp = model_tabla_especialidad.getRowCount();
            if(!lista_especialidad.contains(newEsp)){
                lista_especialidad.add(newEsp);
                jComboBox_especialidad_especialidad.addItem(newEsp.getNombre());
                mostrarNuevoEspecialidad();
                System.out.println("Esp: "+newEsp.toString());
                System.out.println("listaEspecialidad: "+lista_especialidad.size());
            }
           
        } else if (guardarNuevoEsp == false) {
            int id_Esp = positionEsp+1;
            Especialidad setEspecialidad = new Especialidad(id_Esp, nombre, importancia, anosEstudio, categoria, codigoEspecialidad);
            System.out.println("Position: "+positionEsp);
            lista_especialidad.set(positionEsp, setEspecialidad);
            
            model_tabla_especialidad.setValueAt(setEspecialidad.getNombre(), positionEsp, 0);
            model_tabla_especialidad.setValueAt(setEspecialidad.getImportancia(), positionEsp, 1);
            model_tabla_especialidad.setValueAt(setEspecialidad.getAnosEstudio(), positionEsp, 2);            
            model_tabla_especialidad.setValueAt(setEspecialidad.getCategoria(), positionEsp, 3);
            model_tabla_especialidad.setValueAt(setEspecialidad.getCodigoEspecialidad(), positionEsp, 4);
            
            //Cambiar este variable a True si queremos añadir una Esp nueva
            guardarNuevoEsp = true;            
            
            //Bucle que recorra todos los doctores y los inserte en el combobox de Paciente
            jComboBox_especialidad_especialidad.removeAllItems();
            for (int i = 0; i < lista_especialidad.size(); i++) {
                this.jComboBox_especialidad_especialidad.addItem(this.lista_especialidad.get(i).getNombre()); 
            }        
            System.out.println("Esp: "+setEspecialidad);
        }        
       
        jTextField_nombre_especialidad.setEditable(false);
        jTextField_importancia_especialidad.setEditable(false);
        jTextField_anosestudio_especialidad.setEditable(false);
        jTextField_categoria_especialidad.setEditable(false);
        jTextField_codigo_especialidad.setEditable(false);
        jComboBox_especialidad_especialidad.setEditable(false);

        jButton_aniadir_especialidad.setEnabled(true);
        jButton_guardar_especialidad.setEnabled(false);
        jButton_cancelar_especialidad.setEnabled(false);
        jButton_modificar_especialidad.setEnabled(false);
        jButton_borrar_especialidad.setEnabled(false);

        jTextField_nombre_especialidad.setText("");
        jTextField_importancia_especialidad.setText("");
        jTextField_anosestudio_especialidad.setText("");
        jTextField_categoria_especialidad.setText("");
        jTextField_codigo_especialidad.setText("");
        
        
       
    }//GEN-LAST:event_jButton_guardar_especialidadActionPerformed

    private void jTextField_nombre_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_nombre_especialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_nombre_especialidadActionPerformed

    private void jTable_especialidadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_especialidadMouseClicked
        // TODO add your handling code here:
        
        positionEsp = jTable_especialidad.getSelectedRow();
        int col1 = model_tabla_especialidad.getColumnCount();

        for (int j = 0; j < col1; j++) {

            Object obj = model_tabla_especialidad.getValueAt(jTable_especialidad.getSelectedRow(), j);
            switch (j) {
                case 0:
                    jTextField_nombre_especialidad.setText(obj.toString());
                    break;
                case 1:
                    jTextField_importancia_especialidad.setText(obj.toString());
                    break;
                case 2:
                    jTextField_anosestudio_especialidad.setText(obj.toString());
                    break;
                case 3:
                    jTextField_categoria_especialidad.setText(obj.toString());
                    break;
                case 4:
                    jTextField_codigo_especialidad.setText(obj.toString());
                    break;
                default:
                    throw new AssertionError();
            }
        }

        jTextField_nombre_especialidad.setEditable(false);
        jTextField_importancia_especialidad.setEditable(false);
        jTextField_anosestudio_especialidad.setEditable(false);
        jTextField_categoria_especialidad.setEditable(false);
        jTextField_codigo_especialidad.setEditable(false);
        
        jButton_guardar_especialidad.setEnabled(false);
        jButton_cancelar_especialidad.setEnabled(false);
        jButton_aniadir_especialidad.setEnabled(false);
        jButton_modificar_especialidad.setEnabled(true);
        jButton_borrar_especialidad.setEnabled(true);
    
    }//GEN-LAST:event_jTable_especialidadMouseClicked

    private void jTextField_dni_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_dni_pacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_dni_pacienteActionPerformed

    private void jTextField_nombre_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_nombre_pacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_nombre_pacienteActionPerformed

    private void jTextField_email_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_email_pacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_email_pacienteActionPerformed

    private void jTextField_telefono_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_telefono_pacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_telefono_pacienteActionPerformed

    private void jButton_cancelar_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_cancelar_pacienteActionPerformed
        // TODO add your handling code here:
        
        jTextField_dni_paciente.setText("");
        jTextField_nombre_paciente.setText("");
        jTextField_apellidos_paciente.setText("");
        jTextField_email_paciente.setText("");
        jTextField_telefono_paciente.setText("");

        jButton_aniadir_paciente.setEnabled(true);
        jButton_cancelar_paciente.setEnabled(false);
        jButton_guardar_paciente.setEnabled(false);

        jTextField_dni_paciente.setEditable(false);
        jTextField_nombre_paciente.setEditable(false);
        jTextField_apellidos_paciente.setEditable(false);
        jTextField_email_paciente.setEditable(false);
        jTextField_telefono_paciente.setEditable(false);
        jComboBox_especialidad_doctor.setEditable(false);
        
    }//GEN-LAST:event_jButton_cancelar_pacienteActionPerformed

    private void mostrarNuevoPaciente() {

        String[] list = new String[6];
        for (Paciente p : lista_pacientes) {
            list[0] = p.getDNIPaciente();
            list[1] = p.getNombrePaciente();
            list[2] = p.getApellidoPaciente();
            list[3] = p.getEmailPaciente();
            list[4] = p.getTelefonoPaciente();
            list[5] = p.getNombreDoctor();
        }
        model_tabla_paciente.insertRow(positionPac, list);
    }

    private void mostrarTodosLosPacientes() {
        String[] list = new String[6];
        for (Paciente p : lista_pacientes) {
            list[0] = p.getDNIPaciente();
            list[1] = p.getNombrePaciente();
            list[2] = p.getApellidoPaciente();
            list[3] = p.getEmailPaciente();
            list[4] = p.getTelefonoPaciente();
            list[5] = p.getNombreDoctor();

            model_tabla_paciente.insertRow(positionPac, list);
            positionPac++;
        }
    }
    
    private void mostrarNuevoDoctor() {

        String[] list = new String[6];
        for (Doctor doc : lista_doctors) {
            list[0] = doc.getNombre();
            list[1] = doc.getApellido();
            list[2] = doc.getEmail();
            list[3] = doc.getTelefono();
            list[4] = doc.getDireccion();
            list[5] = doc.getEspecialidad();
        }
        model_tabla_doctor.insertRow(positionDoc, list);
    }

    private void mostrarTodosLosDoctores() {
        String[] list = new String[6];
        for (Doctor doc : lista_doctors) {
            list[0] = doc.getNombre();
            list[1] = doc.getApellido();
            list[2] = doc.getEmail();
            list[3] = doc.getTelefono();
            list[4] = doc.getDireccion();
            list[5] = doc.getEspecialidad();

            model_tabla_doctor.insertRow(positionDoc, list);
            positionDoc++;
        }
    }

    
    private void mostrarNuevoEspecialidad() {

        String[] list = new String[5];
        for (Especialidad esp : lista_especialidad) {
            list[0] = esp.getNombre();
            list[1] = esp.getImportancia();
            list[2] = esp.getAnosEstudio()+"";
            list[3] = esp.getCategoria();
            list[4] = esp.getCodigoEspecialidad();
        }
        model_tabla_especialidad.insertRow(positionEsp, list);
    }

    private void mostrarTodosLosEspecialidades() {
        
        String[] list = new String[5];
        for (Especialidad esp : lista_especialidad) {
            list[0] = esp.getNombre();
            list[1] = esp.getImportancia();
            list[2] = esp.getAnosEstudio()+"";
            list[3] = esp.getCategoria();
            list[4] = esp.getCodigoEspecialidad();
        
            model_tabla_especialidad.insertRow(positionEsp, list);
            positionEsp++;
        }        
    }


    private void jButton_guardar_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_guardar_pacienteActionPerformed
        // TODO add your handling code here:
        
        int id_Paciente = positionPac+1;
        String dni = jTextField_dni_paciente.getText();
        String nombre = jTextField_nombre_paciente.getText();
        String apellido = jTextField_apellidos_paciente.getText();
        String email = jTextField_email_paciente.getText();
        String telefono = jTextField_telefono_paciente.getText();
        String nombreDoctor = jComboBox_especialidad_doctor.getSelectedItem().toString();
        
        if (guardarNuevoPac == true) {

            Paciente newPaciente = new Paciente(++id_Paciente, dni, nombre, apellido, email, telefono, nombreDoctor);
            positionPac = model_tabla_paciente.getRowCount();
            lista_pacientes.add(newPaciente);
            mostrarNuevoPaciente();
            System.out.println("lista_pacientes: "+lista_pacientes.size());
        
        } else if (guardarNuevoPac == false) {

            int id_Pac = positionPac+1;
            Paciente setPaciente = new Paciente(id_Pac, dni, nombre, apellido, email, telefono, nombreDoctor);
            lista_pacientes.set(positionPac, setPaciente);
            model_tabla_paciente.setValueAt(setPaciente.getDNIPaciente(), positionPac, 0);
            model_tabla_paciente.setValueAt(setPaciente.getNombrePaciente(), positionPac, 1);
            model_tabla_paciente.setValueAt(setPaciente.getApellidoPaciente(), positionPac, 2);
            model_tabla_paciente.setValueAt(setPaciente.getEmailPaciente(), positionPac, 3);
            model_tabla_paciente.setValueAt(setPaciente.getTelefonoPaciente(), positionPac, 4);
            model_tabla_paciente.setValueAt(setPaciente.getNombreDoctor(), positionPac, 5);
            
            guardarNuevoPac = true;
                        
        }

        jTextField_dni_paciente.setEditable(false);
        jTextField_nombre_paciente.setEditable(false);
        jTextField_apellidos_paciente.setEditable(false);
        jTextField_email_paciente.setEditable(false);
        jTextField_telefono_paciente.setEditable(false);
        //jComboBox_doctor.setEditable(false);

        jButton_aniadir_paciente.setEnabled(true);
        jButton_guardar_paciente.setEnabled(false);
        jButton_cancelar_paciente.setEnabled(false);
        jButton_modificar_paciente.setEnabled(false);
        jButton_borrar_paciente.setEnabled(false);

        jTextField_dni_paciente.setText("");
        jTextField_nombre_paciente.setText("");
        jTextField_apellidos_paciente.setText("");
        jTextField_email_paciente.setText("");
        jTextField_telefono_paciente.setText("");

    }//GEN-LAST:event_jButton_guardar_pacienteActionPerformed

    private void jTextField_apellidos_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_apellidos_pacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_apellidos_pacienteActionPerformed

    private void jButton_borrar_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_borrar_pacienteActionPerformed
        // TODO add your handling code here:
        
        lista_pacientes.remove(positionPac);
        
        model_tabla_paciente.removeRow(positionPac);
        
        jTextField_dni_paciente.setText("");
        jTextField_nombre_paciente.setText("");
        jTextField_apellidos_paciente.setText("");
        jTextField_email_paciente.setText("");
        jTextField_telefono_paciente.setText("");

        jButton_aniadir_paciente.setEnabled(true);
        jButton_modificar_paciente.setEnabled(false);
        jButton_borrar_paciente.setEnabled(false);
        jButton_guardar_paciente.setEnabled(false);
        jButton_cancelar_paciente.setEnabled(false);

    }//GEN-LAST:event_jButton_borrar_pacienteActionPerformed

    private void jButton_modificar_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_modificar_pacienteActionPerformed
        // TODO add your handling code here:
        guardarNuevoPac = false;

        jTextField_dni_paciente.setEditable(true);
        jTextField_nombre_paciente.setEditable(true);
        jTextField_apellidos_paciente.setEditable(true);
        jTextField_email_paciente.setEditable(true);
        jTextField_telefono_paciente.setEditable(true);
        jComboBox_especialidad_doctor.setEditable(true);

        jButton_guardar_paciente.setEnabled(true);
        jButton_cancelar_paciente.setEnabled(true);
        jButton_aniadir_paciente.setEnabled(false);
    }//GEN-LAST:event_jButton_modificar_pacienteActionPerformed

    private void jButton_aniadir_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_aniadir_pacienteActionPerformed
        // TODO add your handling code here:
        
        positionPac = model_tabla_paciente.getRowCount();

        jTextField_dni_paciente.setEditable(true);
        jTextField_nombre_paciente.setEditable(true);
        jTextField_apellidos_paciente.setEditable(true);
        jTextField_email_paciente.setEditable(true);
        jTextField_telefono_paciente.setEditable(true);
        jComboBox_especialidad_doctor.setEditable(true);

        jButton_guardar_paciente.setEnabled(true);
        jButton_cancelar_paciente.setEnabled(true);
        jButton_aniadir_paciente.setEnabled(false);
        
    }//GEN-LAST:event_jButton_aniadir_pacienteActionPerformed

    private void jTable_pacienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_pacienteMouseClicked
        // TODO add your handling code here:
        positionPac = jTable_paciente.getSelectedRow();
        int col1 = model_tabla_paciente.getColumnCount();

        for (int j = 0; j < col1; j++) {

            Object obj = model_tabla_paciente.getValueAt(jTable_paciente.getSelectedRow(), j);
            switch (j) {
                case 0:
                    jTextField_dni_paciente.setText(obj.toString());
                    break;
                case 1:
                    jTextField_nombre_paciente.setText(obj.toString());
                    break;
                case 2:
                    jTextField_apellidos_paciente.setText(obj.toString());
                    break;
                case 3:
                    jTextField_email_paciente.setText(obj.toString());
                    break;
                case 4:
                    jTextField_telefono_paciente.setText(obj.toString());
                    break;
                case 5:
                    jComboBox_especialidad_doctor.setSelectedItem(obj.toString());
                    break;

                default:
                    throw new AssertionError();
            }
        }

        jTextField_dni_paciente.setEditable(false);
        jTextField_nombre_paciente.setEditable(false);
        jTextField_apellidos_paciente.setEditable(false);
        jTextField_email_paciente.setEditable(false);
        jTextField_telefono_paciente.setEditable(false);
        jComboBox_especialidad_doctor.setEditable(false);

        jButton_guardar_paciente.setEnabled(false);
        jButton_cancelar_paciente.setEnabled(false);
        jButton_aniadir_paciente.setEnabled(false);
        jButton_modificar_paciente.setEnabled(true);
        jButton_borrar_paciente.setEnabled(true);
    }//GEN-LAST:event_jTable_pacienteMouseClicked

    private void jTextField_anosestudio_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_anosestudio_especialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_anosestudio_especialidadActionPerformed


    private void jComboBox_especialidad_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_especialidad_doctorActionPerformed
        // TODO add your handling code here:        
    }//GEN-LAST:event_jComboBox_especialidad_doctorActionPerformed

    private void jComboBox_especialidad_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_especialidad_especialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_especialidad_especialidadActionPerformed

    private void jTextField_apellido_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_apellido_doctorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_apellido_doctorActionPerformed

    private void jButton_borrar_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_borrar_doctorActionPerformed
        // TODO add your handling code here:

        lista_doctors.remove(positionDoc);
        jComboBox_especialidad_doctor.removeAllItems();

        //Bucle que recorra todos los especialidad y los inserte en el combobox de Doctor
        for (int i = 0; i < lista_doctors.size(); i++) {
            jComboBox_especialidad_doctor.addItem(lista_doctors.get(i).getNombre());
        }

        model_tabla_doctor.removeRow(positionDoc);

        jTextField_nombre_doctor.setText("");
        jTextField_apellido_doctor.setText("");
        jTextField_email_doctor.setText("");
        jTextField_telefono_doctor.setText("");
        jTextField_direccion_doctor.setText("");

        jButton_aniadir_doctor.setEnabled(true);
        jButton_modificar_doctor.setEnabled(false);
        jButton_borrar_doctor.setEnabled(false);
        jButton_guardar_doctor.setEnabled(false);
        jButton_cancelar_doctor.setEnabled(false);
    }//GEN-LAST:event_jButton_borrar_doctorActionPerformed

    private void jButton_modificar_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_modificar_doctorActionPerformed
        // TODO add your handling code here:
        guardarNuevoDoc = false;

        jTextField_nombre_doctor.setEditable(true);
        jTextField_apellido_doctor.setEditable(true);
        jTextField_email_doctor.setEditable(true);
        jTextField_telefono_doctor.setEditable(true);
        jTextField_direccion_doctor.setEditable(true);
        jComboBox_especialidad_especialidad.setEditable(true);

        jButton_guardar_doctor.setEnabled(true);
        jButton_cancelar_doctor.setEnabled(true);
        jButton_aniadir_doctor.setEnabled(false);

    }//GEN-LAST:event_jButton_modificar_doctorActionPerformed

    private void jButton_aniadir_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_aniadir_doctorActionPerformed
        // TODO add your handling code here:

        positionDoc = model_tabla_doctor.getRowCount();

        jTextField_apellido_doctor.setEditable(true);
        jTextField_direccion_doctor.setEditable(true);
        jTextField_email_doctor.setEditable(true);
        jTextField_nombre_doctor.setEditable(true);
        jTextField_telefono_doctor.setEditable(true);
        jComboBox_especialidad_especialidad.setEditable(true);

        jButton_guardar_doctor.setEnabled(true);
        jButton_cancelar_doctor.setEnabled(true);
        jButton_aniadir_doctor.setEnabled(false);

    }//GEN-LAST:event_jButton_aniadir_doctorActionPerformed

    private void jButton_cancelar_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_cancelar_doctorActionPerformed
        // TODO add your handling code here:

        jTextField_nombre_doctor.setText("");
        jTextField_apellido_doctor.setText("");
        jTextField_email_doctor.setText("");
        jTextField_telefono_doctor.setText("");
        jTextField_direccion_doctor.setText("");
        jComboBox_especialidad_especialidad.setEditable(true);

        jButton_aniadir_doctor.setEnabled(true);
        jButton_cancelar_doctor.setEnabled(false);
        jButton_guardar_doctor.setEnabled(false);

        jTextField_nombre_doctor.setEditable(false);
        jTextField_apellido_doctor.setEditable(false);
        jTextField_email_doctor.setEditable(false);
        jTextField_telefono_doctor.setEditable(false);
        jTextField_direccion_doctor.setEditable(false);
        jComboBox_especialidad_especialidad.setEditable(false);
    }//GEN-LAST:event_jButton_cancelar_doctorActionPerformed

    private void jButton_guardar_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_guardar_doctorActionPerformed
        // TODO add your handling code here

        int id_Doctor = lista_doctors.size();
        String nombre = jTextField_nombre_doctor.getText();
        String apellido = jTextField_apellido_doctor.getText();
        String email = jTextField_email_doctor.getText();
        String telefono = jTextField_telefono_doctor.getText();
        String direccion = jTextField_direccion_doctor.getText();
        String especialidad = jComboBox_especialidad_especialidad.getSelectedItem().toString();

        if (guardarNuevoDoc == true) {

            Doctor newDoctor = new Doctor(++id_Doctor, nombre, apellido, email, telefono, direccion, especialidad);
            positionDoc = model_tabla_doctor.getRowCount();
            lista_doctors.add(newDoctor);
            jComboBox_especialidad_doctor.addItem(newDoctor.getNombre());
            mostrarNuevoDoctor();
            System.out.println("ListDoc: "+lista_doctors.size());

        } else if (guardarNuevoDoc == false) {

            int id_Doc = positionDoc+1;
            Doctor setDoctor = new Doctor(id_Doc, nombre, apellido, email, telefono, direccion, especialidad);
            lista_doctors.set(positionDoc, setDoctor);
            model_tabla_doctor.setValueAt(setDoctor.getNombre(), positionDoc, 0);
            model_tabla_doctor.setValueAt(setDoctor.getApellido(), positionDoc, 1);
            model_tabla_doctor.setValueAt(setDoctor.getEmail(), positionDoc, 2);
            model_tabla_doctor.setValueAt(setDoctor.getTelefono(), positionDoc, 3);
            model_tabla_doctor.setValueAt(setDoctor.getDireccion(), positionDoc, 4);
            model_tabla_doctor.setValueAt(setDoctor.getEspecialidad(), positionDoc, 5);

            guardarNuevoDoc = true;

            //Bucle que recorra todos los doctores y los inserte en el combobox de Paciente
            jComboBox_especialidad_doctor.removeAllItems();
            for (int i = 0; i < lista_doctors.size(); i++) {
                this.jComboBox_especialidad_doctor.addItem(this.lista_doctors.get(i).getNombre());
            }
        }

        jTextField_nombre_doctor.setEditable(false);
        jTextField_apellido_doctor.setEditable(false);
        jTextField_email_doctor.setEditable(false);
        jTextField_telefono_doctor.setEditable(false);
        jTextField_direccion_doctor.setEditable(false);
        jComboBox_especialidad_especialidad.setEditable(false);
        //jComboBox_especialidad_doctor.addItem(doctor.getNombre());

        jButton_aniadir_doctor.setEnabled(true);
        jButton_guardar_doctor.setEnabled(false);
        jButton_cancelar_doctor.setEnabled(false);
        jButton_modificar_doctor.setEnabled(false);
        jButton_borrar_doctor.setEnabled(false);

        jTextField_nombre_doctor.setText("");
        jTextField_apellido_doctor.setText("");
        jTextField_email_doctor.setText("");
        jTextField_telefono_doctor.setText("");
        jTextField_direccion_doctor.setText("");
        //jComboBox_especialidad_especialidad.getText();

    }//GEN-LAST:event_jButton_guardar_doctorActionPerformed

    private void jTextField_email_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_email_doctorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_email_doctorActionPerformed

    private void jTextField_nombre_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_nombre_doctorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_nombre_doctorActionPerformed

    private void jTable_doctorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_doctorMouseClicked
        // TODO add your handling code here:

        positionDoc = jTable_doctor.getSelectedRow();
        int col1 = model_tabla_doctor.getColumnCount();

        for (int j = 0; j < col1; j++) {

            Object obj = model_tabla_doctor.getValueAt(jTable_doctor.getSelectedRow(), j);
            switch (j) {
                case 0:
                jTextField_nombre_doctor.setText(obj.toString());
                break;
                case 1:
                jTextField_apellido_doctor.setText(obj.toString());
                break;
                case 2:
                jTextField_email_doctor.setText(obj.toString());
                break;
                case 3:
                jTextField_telefono_doctor.setText(obj.toString());
                break;
                case 4:
                jTextField_direccion_doctor.setText(obj.toString());
                break;
                case 5:
                jComboBox_especialidad_especialidad.setSelectedItem(obj.toString());
                break;
                default:
                throw new AssertionError();
            }
        }

        jTextField_nombre_doctor.setEditable(false);
        jTextField_apellido_doctor.setEditable(false);
        jTextField_email_doctor.setEditable(false);
        jTextField_telefono_doctor.setEditable(false);
        jTextField_direccion_doctor.setEditable(false);
        jComboBox_especialidad_especialidad.setEditable(false);

        jButton_guardar_doctor.setEnabled(false);
        jButton_cancelar_doctor.setEnabled(false);
        jButton_aniadir_doctor.setEnabled(false);
        jButton_modificar_doctor.setEnabled(true);
        jButton_borrar_doctor.setEnabled(true);

    }//GEN-LAST:event_jTable_doctorMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_aniadir_doctor;
    private javax.swing.JButton jButton_aniadir_especialidad;
    private javax.swing.JButton jButton_aniadir_paciente;
    private javax.swing.JButton jButton_borrar_doctor;
    private javax.swing.JButton jButton_borrar_especialidad;
    private javax.swing.JButton jButton_borrar_paciente;
    private javax.swing.JButton jButton_cancelar_doctor;
    public javax.swing.JButton jButton_cancelar_especialidad;
    private javax.swing.JButton jButton_cancelar_paciente;
    private javax.swing.JButton jButton_guardar_doctor;
    public javax.swing.JButton jButton_guardar_especialidad;
    private javax.swing.JButton jButton_guardar_paciente;
    private javax.swing.JButton jButton_modificar_doctor;
    private javax.swing.JButton jButton_modificar_especialidad;
    private javax.swing.JButton jButton_modificar_paciente;
    private javax.swing.JComboBox<String> jComboBox_especialidad_doctor;
    private javax.swing.JComboBox<String> jComboBox_especialidad_especialidad;
    private javax.swing.JLabel jLabel_apellido_doctor;
    private javax.swing.JLabel jLabel_apellido_paciente;
    private javax.swing.JLabel jLabel_categoria_especialidad;
    private javax.swing.JLabel jLabel_codespecialidad_especialidad;
    private javax.swing.JLabel jLabel_direccion_doctor;
    private javax.swing.JLabel jLabel_dni_paciente;
    private javax.swing.JLabel jLabel_email_doctor;
    private javax.swing.JLabel jLabel_email_paciente;
    private javax.swing.JLabel jLabel_especialidad_doctor;
    private javax.swing.JLabel jLabel_importancia_especialidad;
    private javax.swing.JLabel jLabel_nombre_doctor;
    private javax.swing.JLabel jLabel_nombre_especialidad;
    private javax.swing.JLabel jLabel_nombre_paciente1;
    private javax.swing.JLabel jLabel_telefono_doctor;
    private javax.swing.JLabel jLabel_telefono_paciente;
    private javax.swing.JLabel jLabel_telefono_paciente1;
    private javax.swing.JLabel jLabel_yearestudio_especialidad;
    private javax.swing.JPanel jPanel_Especialidad;
    private javax.swing.JPanel jPanel_doctor;
    private javax.swing.JPanel jPanel_paciente;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane;
    public javax.swing.JTable jTable_doctor;
    private javax.swing.JTable jTable_especialidad;
    public javax.swing.JTable jTable_paciente;
    private javax.swing.JFormattedTextField jTextField_anosestudio_especialidad;
    public javax.swing.JTextField jTextField_apellido_doctor;
    public javax.swing.JTextField jTextField_apellidos_paciente;
    private javax.swing.JTextField jTextField_categoria_especialidad;
    private javax.swing.JTextField jTextField_codigo_especialidad;
    public javax.swing.JTextField jTextField_direccion_doctor;
    private javax.swing.JTextField jTextField_dni_paciente;
    public javax.swing.JTextField jTextField_email_doctor;
    private javax.swing.JFormattedTextField jTextField_email_paciente;
    private javax.swing.JTextField jTextField_importancia_especialidad;
    public javax.swing.JTextField jTextField_nombre_doctor;
    private javax.swing.JTextField jTextField_nombre_especialidad;
    public javax.swing.JTextField jTextField_nombre_paciente;
    private javax.swing.JFormattedTextField jTextField_telefono_doctor;
    public javax.swing.JTextField jTextField_telefono_paciente;
    // End of variables declaration//GEN-END:variables

    public void formWindowClosing(java.awt.event.WindowEvent evt) {
        // A mettre qu'on veut fermer la solution (close)
        
        //Guardar fichero serialisable de Pacientes 
        for(Paciente paciente : lista_pacientes){
            try{
                dataOS_pac.writeObject(paciente);
                dataOS_pac.flush();
                System.out.println("Sise de la lista Pacientes: "+lista_pacientes.size());
            }catch(Exception e){
                
            }
        }
        //Guardar fichero serialisable de Doctores
        for(Doctor doctor : lista_doctors){
            try{
                dataOS_doc.writeObject(doctor);
                dataOS_doc.flush();
                System.out.println("Sise de la lista doctores: "+lista_doctors.size());
            }catch(Exception e){
                
            }
        }
        //Guardar fichero serialisable de Especialidad
        for(Especialidad esp_serialisable : lista_especialidad){
            try{
                dataOS_esp.writeObject(esp_serialisable);
                dataOS_esp.flush();
                System.out.println("Sise de la listaEspecialidad: "+lista_especialidad.size());
            }catch(Exception e){
                
            }
        }
    }
    
    /*
    //Para Escribir fichero serialisable
    public void EscribirFichObject(Object obj, File fichero) throws FileNotFoundException, IOException {
       //crea el flujo de salida
       FileOutputStream fileout = new FileOutputStream(fichero,true);  
       //conecta el flujo de bytes al flujo de datos
       ObjectOutputStream dataOS = new ObjectOutputStream(fileout);
       //escribo el objeto en el fichero
       dataOS.writeObject(obj);
    
       System.out.println("GRABO1 LOS DATOS DE OBJECT.");
       //cerrar stream de salida 
       dataOS.flush();
       fileout.flush();
       //dataOS.close();   
    }
    */
    //Para leer fichero serialisable Paciente
    public static ArrayList<Paciente> LeerFichObjectPaciente (File fichero){           
        
        ArrayList<Paciente> list = new ArrayList<>();
        FileInputStream fis = null;
        ObjectInputStream dataIS = null;
        try{
            fis = new FileInputStream(fichero);
            dataIS = new ObjectInputStream(fis);
            System.out.println("Leer Fichero Object Paciente Avant while");
            
            Object obj = null;
            while( (fis.available()>0)
                    && (obj=dataIS.readObject())!=null){
                if(obj instanceof Paciente){
                    Paciente pac = (Paciente)obj;
                    System.out.println("Leer Pac seriali: "+pac.toString());
                    if(!list.contains(pac))
                        list.add(pac);
                }
            }
            System.out.println("Size list pac serialis: "+list.size());
        }catch(Exception e){
            
        }finally{
            try {
                dataIS.close();
                return list;
            } catch (IOException ex) {
                Logger.getLogger(Ventana1.class.getName()).log(Level.SEVERE, null, ex);
            }                           
        }
        return list;
    }
       
    
    //Para leer fichero serialisable Doctor
    public static ArrayList<Doctor> LeerFichObjectDoctor (File fichero){           
        
        ArrayList<Doctor> list = new ArrayList<>();
        FileInputStream fis = null;
        ObjectInputStream dataIS = null;
        try{
            fis = new FileInputStream(fichero);
            dataIS = new ObjectInputStream(fis);
            System.out.println("Leer Fichero Object Doctor Avant while");
            
            Object obj = null;
            while( (fis.available()>0)
                    && (obj=dataIS.readObject())!=null){
                if(obj instanceof Doctor){
                    Doctor doc = (Doctor)obj;
                    System.out.println("Leer Doc seriali: "+doc.toString());
                    if(!list.contains(doc))
                        list.add(doc);
                }
            }
            System.out.println("Size list esp serialis: "+list.size());
        }catch(Exception e){
            
        }finally{
            try {
                dataIS.close();
                return list;
            } catch (IOException ex) {
                Logger.getLogger(Ventana1.class.getName()).log(Level.SEVERE, null, ex);
            }                           
        }
        return list;
    }
    
    
    //Para leer fichero serialisable Especialidad
    public static ArrayList<Especialidad> LeerFichObjectEspecialidad (File fichero){           
        
        ArrayList<Especialidad> list = new ArrayList<>();
        FileInputStream fis = null;
        ObjectInputStream dataIS = null;
        try{
            fis = new FileInputStream(fichero);
            dataIS = new ObjectInputStream(fis);
            System.out.println("Leer Fichero Object Especialidad Avant while");
            
            Object obj = null;
            while( (fis.available()>0)
                    && (obj=dataIS.readObject())!=null){
                if(obj instanceof Especialidad){
                    Especialidad esp = (Especialidad)obj;
                    System.out.println("Leer Esp seriali: "+esp.toString());
                    if(!list.contains(esp))
                        list.add(esp);
                }
            }
            System.out.println("Size list esp serialis: "+list.size());
        }catch(Exception e){
            
        }finally{
            try {
                dataIS.close();
                return list;
            } catch (IOException ex) {
                Logger.getLogger(Ventana1.class.getName()).log(Level.SEVERE, null, ex);
            }                           
        }
        return list;
    }
    
    
    
    
    ///////////////////////////
    //Point zero
}

