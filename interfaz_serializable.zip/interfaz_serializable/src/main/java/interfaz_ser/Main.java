
package interfaz_ser;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.NotSerializableException;
import org.xml.sax.SAXException;




public class Main {
    
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException, NotSerializableException, SAXException{
        
        java.awt.EventQueue.invokeLater(new Runnable(){
            @Override
            public void run(){
                Ventana1 v = new Ventana1();
                v.setVisible(true);
            }    
        });
        
    }
}

/*
 java.awt.EventQueue.invokeLater(
                new Runnable() {
                    @Override
                    public void run(){
                        try {
                            Ventana1 v = new Ventana1();
                            v.setVisible(true);
                        } catch (IOException ex) {
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (SAXException ex) {
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }    
                });
*/