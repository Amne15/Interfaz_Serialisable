/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit3TestClass.java to edit this template
 */
package interfaz_ser;

import junit.framework.TestCase;

/**
 *
 * @author usuario
 */
public class EspecialidadTest extends TestCase {
    
    public void comprobarNombreEspecialidad() {
        
        Especialidad especialidadUno = new Especialidad();
        
        especialidadUno.setNombre("Especialidad Uno");
        
        assert(especialidadUno.getNombre().equals("Especialidad Uno"));
    }

    /**
     * Test of getIdEspecialidad method, of class Especialidad.
     */
    public void testGetIdEspecialidad() {
    }

    /**
     * Test of getNombre method, of class Especialidad.
     */
    public void testGetNombre() {
    }

    /**
     * Test of setNombre method, of class Especialidad.
     */
    public void testSetNombre() {
    }

    /**
     * Test of getImportancia method, of class Especialidad.
     */
    public void testGetImportancia() {
    }

    /**
     * Test of setImportancia method, of class Especialidad.
     */
    public void testSetImportancia() {
    }

    /**
     * Test of getAnosEstudio method, of class Especialidad.
     */
    public void testGetAnosEstudio() {
    }

    /**
     * Test of setAnosEstudio method, of class Especialidad.
     */
    public void testSetAnosEstudio() {
    }

    /**
     * Test of getCategoria method, of class Especialidad.
     */
    public void testGetCategoria() {
    }

    /**
     * Test of setCategoria method, of class Especialidad.
     */
    public void testSetCategoria() {
    }

    /**
     * Test of getCodigoEspecialidad method, of class Especialidad.
     */
    public void testGetCodigoEspecialidad() {
    }

    /**
     * Test of setCodigoEspecialidad method, of class Especialidad.
     */
    public void testSetCodigoEspecialidad() {
    }

    /**
     * Test of toString method, of class Especialidad.
     */
    public void testToString() {
    }
    
}
