/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit3TestClass.java to edit this template
 */
package interfaz_ser;

import junit.framework.TestCase;

/**
 *
 * @author usuario
 */
public class PacienteTest extends TestCase {
    
    public PacienteTest(String testName) {
       // super(testName);
           Paciente pacienteUno = new Paciente();
        
        pacienteUno.setApellidoPaciente("Apellido Uno");
        
        assert(pacienteUno.getApellidoPaciente().equals("Apelliudo Uno"));
    }
    
    
}
