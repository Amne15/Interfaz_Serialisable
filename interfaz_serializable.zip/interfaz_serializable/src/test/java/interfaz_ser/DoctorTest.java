/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit3TestClass.java to edit this template
 */
package interfaz_ser;

import junit.framework.TestCase;
        

/**
 *
 * @author usuario
 */
public class DoctorTest extends TestCase {
    
   
    /**
     * Test of toString method, of class Doctor.
     */
    public void comprobarNombreDoctor() {
        
        Doctor doctorUno = new Doctor();
        
        doctorUno.setNombre("Amin");
        
        assert(doctorUno.getNombre().equals("Amin"));
    }
    
}
